package com.cbta.mediacenter.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

const val TYPE_AUDIO = "audio"
const val TYPE_VIDEO = "video"
const val TYPE_COMMAND = "command"

const val ST_QUEUED = "queued"
const val ST_RUNNING = "running"
const val ST_DONE = "done"
const val ST_ERROR = "error"
const val ST_CANCELLED = "cancelled"
const val ST_SCHEDULED = "scheduled"

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String = "",
    val thumb: String = "",
    val author: String = "",
    val type: String = TYPE_VIDEO,
    val selector: String = "",
    val audioFormat: String = "mp3",
    val container: String = "mp4",
    val command: String = "",
    val embedSubs: Boolean = false,
    val embedThumb: Boolean = false,
    val splitChapters: Boolean = false,
    val noPlaylist: Boolean = true,
    val status: String = ST_QUEUED,
    val log: String = "",
    val filePath: String = "",
    val fileName: String = "",
    val scheduledAt: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "templates")
data class Template(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val content: String
)

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY id DESC") fun all(): Flow<List<DownloadItem>>
    @Query("SELECT * FROM downloads WHERE id = :id") suspend fun get(id: Long): DownloadItem?
    @Query("SELECT * FROM downloads WHERE status = 'queued' ORDER BY id") suspend fun queued(): List<DownloadItem>
    @Query("SELECT COUNT(*) FROM downloads WHERE status = 'queued'") suspend fun countQueued(): Int
    @Query("SELECT * FROM downloads WHERE status = 'scheduled'") suspend fun scheduled(): List<DownloadItem>
    @Query("UPDATE downloads SET status = 'error', log = 'Interrupted' WHERE status = 'running'") suspend fun markInterrupted()
    @Query("DELETE FROM downloads WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM downloads WHERE status IN ('done','error','cancelled')") suspend fun clearFinished()
    @Insert suspend fun insert(item: DownloadItem): Long
    @Update suspend fun update(item: DownloadItem)
}

@Dao
interface TemplateDao {
    @Query("SELECT * FROM templates ORDER BY name") fun all(): Flow<List<Template>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(t: Template)
    @Query("DELETE FROM templates WHERE id = :id") suspend fun delete(id: Long)
}

@Database(entities = [DownloadItem::class, Template::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun downloads(): DownloadDao
    abstract fun templates(): TemplateDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "cbta.db")
                .fallbackToDestructiveMigration()
                .build().also { inst = it }
        }
    }
}
