package com.cbta.mediacenter.core

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.cbta.mediacenter.R
import com.cbta.mediacenter.ui.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine

object Notifier {
    const val CH_PROGRESS = "progress"
    const val CH_DONE = "done"

    fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, c.getString(R.string.ch_progress), NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, c.getString(R.string.ch_done), NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun openApp(c: Context) = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE
    )

    fun progress(c: Context, pct: Int, text: String): Notification =
        NotificationCompat.Builder(c, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(c.getString(R.string.app_name))
            .setContentText(text)
            .setProgress(100, pct, pct == 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(c))
            .build()

    @SuppressLint("MissingPermission")
    fun done(c: Context, id: Long, title: String, ok: Boolean) {
        val nm = NotificationManagerCompat.from(c)
        if (!nm.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(c, CH_DONE)
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(c.getString(if (ok) R.string.notif_done else R.string.notif_failed))
            .setContentText(title)
            .setAutoCancel(true)
            .setContentIntent(openApp(c))
            .build()
        nm.notify(1000 + id.toInt(), n)
    }
}

class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watching = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(
            this, NOTIF_ID, Notifier.progress(this, 0, getString(R.string.notif_downloading)),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        DownloadManager.onServiceStart(intent?.getLongExtra(EXTRA_ID, -1L) ?: -1L)
        if (!watching) {
            watching = true
            scope.launch {
                delay(3000) // grace period while the queue is being filled
                val nm = getSystemService(NotificationManager::class.java)
                DownloadManager.status.combine(DownloadManager.progress) { s, p -> s to p }
                    .collect { (s, p) ->
                        if (s.active == 0 && s.queued == 0) {
                            stopSelf()
                        } else {
                            val avg = if (p.isEmpty()) 0 else p.values.map { it.percent }.average().toInt()
                            nm.notify(NOTIF_ID, Notifier.progress(this@DownloadService, avg, "${s.active} • ${avg}%"))
                        }
                    }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ID = "id"
        private const val NOTIF_ID = 1

        fun start(c: Context, id: Long = -1L) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, DownloadService::class.java).putExtra(EXTRA_ID, id))
            } catch (e: Exception) {
                // Background start was refused by the OS: still run the downloads inside the process.
                DownloadManager.onServiceStart(id)
            }
        }
    }
}
