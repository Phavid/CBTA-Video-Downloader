package com.cbta.mediacenter.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    var maxConcurrent: Int
        get() = sp.getInt("max", 2)
        set(v) = sp.edit().putInt("max", v).apply()
    var nameTemplate: String
        get() = sp.getString("tpl", DEFAULT_TPL) ?: DEFAULT_TPL
        set(v) = sp.edit().putString("tpl", v.ifBlank { DEFAULT_TPL }).apply()
    var useAria: Boolean
        get() = sp.getBoolean("aria", false)
        set(v) = sp.edit().putBoolean("aria", v).apply()
    var fragments: Int
        get() = sp.getInt("frag", 4)
        set(v) = sp.edit().putInt("frag", v).apply()
    var subLangs: String
        get() = sp.getString("subs", "en.*,km.*") ?: "en.*,km.*"
        set(v) = sp.edit().putString("subs", v.ifBlank { "en.*" }).apply()
    var treeUri: String?
        get() = sp.getString("tree", null)
        set(v) = sp.edit().putString("tree", v).apply()

    companion object {
        // 60 characters keeps Khmer titles under the 255-byte file name limit
        const val DEFAULT_TPL = "%(title).60s.%(ext)s"
    }
}
