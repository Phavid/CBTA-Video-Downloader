package com.cbta.mediacenter.core

import android.content.Context
import com.cbta.mediacenter.data.*
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.concurrent.ConcurrentHashMap

data class Prog(val percent: Int, val eta: Long)
data class QueueStatus(val active: Int = 0, val queued: Int = 0)

object DownloadManager {
    lateinit var app: Context
        private set

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val progress = MutableStateFlow<Map<Long, Prog>>(emptyMap())
    val status = MutableStateFlow(QueueStatus())

    private val jobs = ConcurrentHashMap<Long, Pair<Job, String>>()
    private val cancelled = ConcurrentHashMap.newKeySet<Long>()
    private val lock = Mutex()
    private val dao get() = AppDb.get(app).downloads()

    fun init(c: Context) {
        app = c.applicationContext
        scope.launch { dao.markInterrupted() }
    }

    fun enqueue(items: List<DownloadItem>) {
        scope.launch {
            var anyQueued = false
            for (it0 in items) {
                val id = dao.insert(it0)
                if (it0.status == ST_SCHEDULED) Scheduler.schedule(app, id, it0.scheduledAt) else anyQueued = true
            }
            if (anyQueued) DownloadService.start(app)
        }
    }

    /** Called by the service (and as a fallback by the alarm receiver). */
    fun onServiceStart(scheduledId: Long) {
        scope.launch {
            lock.withLock {
                if (scheduledId > 0) {
                    dao.get(scheduledId)?.let { if (it.status == ST_SCHEDULED) dao.update(it.copy(status = ST_QUEUED)) }
                }
                dispatch()
            }
        }
    }

    private fun kick() { scope.launch { lock.withLock { dispatch() } } }

    private suspend fun dispatch() {
        val max = Prefs(app).maxConcurrent.coerceAtLeast(1)
        for (q in dao.queued()) {
            if (jobs.size >= max) break
            if (jobs.containsKey(q.id)) continue
            launchJob(q)
        }
        status.value = QueueStatus(jobs.size, dao.countQueued())
    }

    private suspend fun launchJob(item: DownloadItem) {
        dao.update(item.copy(status = ST_RUNNING, log = ""))
        val pid = "dl-${item.id}"
        val job = scope.launch(start = CoroutineStart.LAZY) {
            try {
                runDownload(item, pid)
            } finally {
                jobs.remove(item.id)
                progress.update { it - item.id }
                kick()
            }
        }
        jobs[item.id] = job to pid
        job.start()
    }

    private suspend fun runDownload(item: DownloadItem, pid: String) {
        val prefs = Prefs(app)
        val dir = File(app.filesDir, "dl/${item.id}").apply { deleteRecursively(); mkdirs() }
        val log = StringBuilder()
        try {
            Ytdlp.awaitReady()
            val req = Ytdlp.buildRequest(app, item, dir, prefs)
            YoutubeDL.getInstance().execute(req, pid) { p, eta, line ->
                progress.update { it + (item.id to Prog(p.toInt().coerceIn(0, 100), eta)) }
                if (log.length < 3000) log.appendLine(line)
            }
            val files = Ytdlp.outputFiles(dir)
            if (files.isEmpty()) throw IllegalStateException("No output file was produced")
            var uri = ""
            var name = ""
            for (f in files) {
                val (u, n) = Storage.save(app, f, prefs)
                if (uri.isEmpty()) { uri = u; name = n }
            }
            val title = item.title.ifBlank { name.substringBeforeLast('.') }
            dao.update(item.copy(status = ST_DONE, title = title, filePath = uri, fileName = name))
            Notifier.done(app, item.id, title, true)
        } catch (e: Exception) {
            val st = if (cancelled.remove(item.id)) ST_CANCELLED else ST_ERROR
            val msg = (e.message ?: e.toString()).takeLast(1500)
            dao.update(item.copy(status = st, log = msg))
            if (st == ST_ERROR) Notifier.done(app, item.id, item.title.ifBlank { item.url }, false)
        } finally {
            dir.deleteRecursively()
        }
    }

    fun cancel(id: Long) {
        scope.launch {
            val j = jobs[id]
            if (j != null) {
                cancelled.add(id)
                YoutubeDL.getInstance().destroyProcessById(j.second)
            } else {
                dao.get(id)?.let { dao.update(it.copy(status = ST_CANCELLED)) }
                Scheduler.cancel(app, id)
            }
        }
    }

    fun retry(id: Long) {
        scope.launch {
            dao.get(id)?.let { dao.update(it.copy(status = ST_QUEUED, log = "")) }
            DownloadService.start(app)
        }
    }

    fun remove(id: Long) {
        scope.launch {
            if (jobs.containsKey(id)) cancel(id)
            Scheduler.cancel(app, id)
            dao.delete(id)
        }
    }

    fun clearFinished() { scope.launch { dao.clearFinished() } }

    fun rescheduleAll() {
        scope.launch {
            val now = System.currentTimeMillis()
            for (s in dao.scheduled()) Scheduler.schedule(app, s.id, maxOf(s.scheduledAt, now + 5000))
        }
    }
}
