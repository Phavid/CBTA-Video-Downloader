package com.cbta.mediacenter.core

import android.content.Context
import com.cbta.mediacenter.data.*
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch

data class Fmt(
    val id: String, val ext: String, val height: Int, val abr: Int,
    val hasVideo: Boolean, val hasAudio: Boolean, val size: Long
)

data class Entry(val url: String, val title: String)

data class MediaInfo(
    val url: String, val title: String, val thumb: String, val author: String,
    val formats: List<Fmt>, val entries: List<Entry>
) {
    val isPlaylist get() = entries.isNotEmpty()
}

object Ytdlp {
    private val latch = CountDownLatch(1)
    @Volatile var initError: String? = null

    fun markReady(error: String?) { initError = error; latch.countDown() }

    /** Blocks (call from a background thread) until yt-dlp, FFmpeg and aria2c are initialised. */
    fun awaitReady() {
        latch.await()
        initError?.let { throw IllegalStateException("yt-dlp init failed: $it") }
    }

    fun cookiesFile(ctx: Context) = File(ctx.filesDir, "cookies.txt")

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

    fun fetchInfo(ctx: Context, input: String, noPlaylist: Boolean): MediaInfo {
        awaitReady()
        val target = if (input.startsWith("http")) input else "ytsearch10:$input"
        val r = YoutubeDLRequest(target)
        r.addOption("-J")
        r.addOption("--flat-playlist")
        r.addOption("--no-warnings")
        if (noPlaylist && input.startsWith("http")) r.addOption("--no-playlist")
        addCookies(ctx, r)
        val resp = YoutubeDL.getInstance().execute(r, "info-${System.nanoTime()}") { _, _, _ -> }
        val txt = resp.out.trim()
        val start = txt.indexOf('{')
        if (start < 0) throw IllegalStateException("No data returned")
        return parse(JSONObject(txt.substring(start)), input)
    }

    private fun parse(j: JSONObject, input: String): MediaInfo {
        val entries = mutableListOf<Entry>()
        j.optJSONArray("entries")?.let { arr ->
            for (k in 0 until arr.length()) {
                val e = arr.optJSONObject(k) ?: continue
                var u = e.str("url")
                if (!u.startsWith("http")) u = e.str("webpage_url")
                if (!u.startsWith("http")) {
                    val id = e.str("id")
                    u = if (e.str("ie_key").startsWith("Youtube") && id.isNotEmpty())
                        "https://www.youtube.com/watch?v=$id" else continue
                }
                entries += Entry(u, e.str("title").ifBlank { u })
            }
        }
        val formats = mutableListOf<Fmt>()
        j.optJSONArray("formats")?.let { arr ->
            for (k in 0 until arr.length()) {
                val f = arr.optJSONObject(k) ?: continue
                val v = f.str("vcodec")
                val a = f.str("acodec")
                val hasV = v.isNotEmpty() && v != "none"
                val hasA = a.isNotEmpty() && a != "none"
                formats += Fmt(
                    f.str("format_id"), f.str("ext"), f.optInt("height", 0),
                    f.optDouble("abr", 0.0).toInt(), hasV, hasA,
                    f.optLong("filesize", f.optLong("filesize_approx", 0))
                )
            }
        }
        return MediaInfo(
            url = j.str("webpage_url").ifBlank { input },
            title = j.str("title").ifBlank { input },
            thumb = j.str("thumbnail").takeIf { it.startsWith("http") } ?: "",
            author = j.str("uploader"),
            formats = formats,
            entries = entries
        )
    }

    private fun addCookies(ctx: Context, r: YoutubeDLRequest) {
        val c = cookiesFile(ctx)
        if (c.exists() && c.length() > 0) r.addOption("--cookies", c.absolutePath)
    }

    fun buildRequest(ctx: Context, item: DownloadItem, dir: File, p: Prefs): YoutubeDLRequest {
        val r = YoutubeDLRequest(item.url)
        val outTpl = File(dir, p.nameTemplate).absolutePath
        if (item.type == TYPE_COMMAND) {
            val toks = tokenize(item.command)
            applyTokens(r, toks)
            if (toks.none { it == "-o" || it == "--output" }) r.addOption("-o", outTpl)
        } else {
            r.addOption("-o", outTpl)
            r.addOption("--no-mtime")
            if (item.noPlaylist) r.addOption("--no-playlist")
            if (p.fragments > 1) r.addOption("-N", p.fragments.toString())
            if (item.type == TYPE_AUDIO) {
                r.addOption("-f", item.selector.ifBlank { "ba/b" })
                r.addOption("-x")
                r.addOption("--audio-format", item.audioFormat)
                r.addOption("--audio-quality", "0")
            } else {
                r.addOption("-f", item.selector.ifBlank { "bv*+ba/b" })
                r.addOption("--merge-output-format", item.container)
                if (item.embedSubs) {
                    r.addOption("--write-subs")
                    r.addOption("--write-auto-subs")
                    r.addOption("--sub-langs", p.subLangs)
                    r.addOption("--embed-subs")
                }
            }
            if (item.embedThumb) {
                r.addOption("--embed-thumbnail")
                r.addOption("--convert-thumbnails", "jpg")
            }
            r.addOption("--embed-metadata")
            if (item.splitChapters) r.addOption("--split-chapters")
        }
        addCookies(ctx, r)
        if (p.useAria) r.addOption("--downloader", "libaria2c.so")
        return r
    }

    private val MEDIA_EXT = setOf(
        "mp4", "mkv", "webm", "mp3", "m4a", "opus", "flac", "wav", "aac", "ogg",
        "mov", "avi", "flv", "3gp", "m4v", "ts"
    )

    fun outputFiles(dir: File): List<File> {
        val all = dir.walkTopDown().filter {
            it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && !it.name.endsWith(".json")
        }.toList()
        val media = all.filter { it.extension.lowercase() in MEDIA_EXT }
        return media.ifEmpty { all }
    }

    /** Splits a command line into tokens, honouring single and double quotes. */
    fun tokenize(s: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var quote: Char? = null
        var has = false
        for (c in s) {
            when {
                quote != null -> if (c == quote) quote = null else sb.append(c)
                c == '"' || c == '\'' -> { quote = c; has = true }
                c.isWhitespace() -> if (sb.isNotEmpty() || has) { out += sb.toString(); sb.clear(); has = false }
                else -> sb.append(c)
            }
        }
        if (sb.isNotEmpty() || has) out += sb.toString()
        return out
    }

    /** Adds raw tokens to a request, keeping "--option value" pairs together. */
    fun applyTokens(r: YoutubeDLRequest, t: List<String>) {
        var i = 0
        while (i < t.size) {
            val a = t[i]
            if (a.startsWith("-") && i + 1 < t.size && !t[i + 1].startsWith("-")) {
                r.addOption(a, t[i + 1]); i += 2
            } else {
                r.addOption(a); i++
            }
        }
    }
}
