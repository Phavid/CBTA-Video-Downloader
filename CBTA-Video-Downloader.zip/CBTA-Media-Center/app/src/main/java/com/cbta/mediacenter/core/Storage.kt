package com.cbta.mediacenter.core

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.cbta.mediacenter.R
import com.cbta.mediacenter.data.DownloadItem
import com.cbta.mediacenter.data.Prefs
import java.io.File

object Storage {
    private const val FOLDER = "CBTA Media Center"

    fun mimeOf(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"

    /** Copies a finished file out of the private temp folder. Returns (uri-or-path, file name). */
    fun save(ctx: Context, src: File, prefs: Prefs): Pair<String, String> {
        val mime = mimeOf(src.name)
        val tree = prefs.treeUri
        if (tree != null) {
            val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(tree))
                ?: throw IllegalStateException("Save folder is not available")
            val f = dir.createFile(mime, src.name)
                ?: throw IllegalStateException("Cannot create file in the chosen folder")
            ctx.contentResolver.openOutputStream(f.uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
            return f.uri.toString() to (f.name ?: src.name)
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, src.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            resolver.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri.toString() to src.name
        }
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER)
        dir.mkdirs()
        val dest = File(dir, src.name)
        src.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.path), null, null)
        return dest.absolutePath to dest.name
    }

    private fun uriOf(ctx: Context, item: DownloadItem): Uri =
        if (item.filePath.startsWith("content:")) Uri.parse(item.filePath)
        else FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", File(item.filePath))

    fun open(ctx: Context, item: DownloadItem) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(ctx, item), mimeOf(item.fileName))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.cannot_open, Toast.LENGTH_SHORT).show()
        }
    }

    fun share(ctx: Context, item: DownloadItem) {
        try {
            val send = Intent(Intent.ACTION_SEND).setType(mimeOf(item.fileName))
                .putExtra(Intent.EXTRA_STREAM, uriOf(ctx, item))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.cannot_open, Toast.LENGTH_SHORT).show()
        }
    }
}
