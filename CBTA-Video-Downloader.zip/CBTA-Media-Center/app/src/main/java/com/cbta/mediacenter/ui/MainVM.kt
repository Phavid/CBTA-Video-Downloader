package com.cbta.mediacenter.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cbta.mediacenter.R
import com.cbta.mediacenter.core.*
import com.cbta.mediacenter.data.*
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainVM(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    val prefs = Prefs(app)
    private val db = AppDb.get(app)

    var tab by mutableStateOf(0)
    var message by mutableStateOf<String?>(null)

    // Home state
    var url by mutableStateOf("")
    var noPlaylist by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var info by mutableStateOf<MediaInfo?>(null)
    var type by mutableStateOf(TYPE_VIDEO)
    var selector by mutableStateOf("")
    var audioFormat by mutableStateOf("mp3")
    var container by mutableStateOf("mp4")
    var command by mutableStateOf("")
    var embedSubs by mutableStateOf(false)
    var embedThumb by mutableStateOf(false)
    var split by mutableStateOf(false)
    val selected = mutableStateListOf<Int>()

    val downloads = db.downloads().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val templates = db.templates().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- Home ----
    fun fetch() {
        val u = url.trim()
        if (u.isEmpty()) return
        loading = true
        error = null
        info = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val r = Ytdlp.fetchInfo(ctx, u, noPlaylist)
                selected.clear()
                if (r.isPlaylist) selected.addAll(r.entries.indices)
                selector = ""
                info = r
            } catch (e: Exception) {
                error = (e.message ?: e.toString()).takeLast(400)
            }
            loading = false
        }
    }

    private fun sizeText(f: Fmt) = if (f.size > 0) " · ${f.size / 1048576}MB" else ""

    /** (yt-dlp selector, label) pairs for the quality picker. */
    fun qualityOptions(): List<Pair<String, String>> {
        val i = info
        val best = "" to ctx.getString(R.string.best)
        val single = i != null && !i.isPlaylist
        if (type == TYPE_AUDIO) {
            val raw = if (single) i!!.formats.filter { it.hasAudio && !it.hasVideo }
                .map { it.id to "${it.id} · ${it.ext} · ${it.abr}kbps${sizeText(it)}" } else emptyList()
            return listOf(best) + raw
        }
        val heights = if (single) i!!.formats.filter { it.hasVideo && it.height > 0 }
            .map { it.height }.distinct().sortedDescending()
        else listOf(2160, 1440, 1080, 720, 480, 360, 240)
        val byHeight = heights.map { h -> "bv*[height<=$h]+ba/b[height<=$h]" to "${h}p" }
        val raw = if (single) i!!.formats.filter { it.hasVideo }.map { f ->
            (if (f.hasAudio) f.id else "${f.id}+ba/b") to "${f.id} · ${f.ext} · ${f.height}p${sizeText(f)}"
        } else emptyList()
        return listOf(best) + byHeight + raw
    }

    private fun baseItem(at: Long) = DownloadItem(
        url = "", type = type, selector = selector, audioFormat = audioFormat, container = container,
        command = command, embedSubs = embedSubs && type == TYPE_VIDEO, embedThumb = embedThumb && type != TYPE_COMMAND,
        splitChapters = split && type == TYPE_VIDEO, noPlaylist = type != TYPE_COMMAND,
        status = if (at > 0) ST_SCHEDULED else ST_QUEUED, scheduledAt = at
    )

    fun queue(at: Long = 0) {
        val when0 = if (at > 0) maxOf(at, System.currentTimeMillis() + 5000) else 0L
        val base = baseItem(when0)
        val i = info
        val items = when {
            i != null && i.isPlaylist -> selected.sorted().map { idx ->
                val e = i.entries[idx]
                base.copy(url = e.url, title = e.title)
            }
            i != null -> listOf(base.copy(url = i.url, title = i.title, thumb = i.thumb, author = i.author))
            url.isNotBlank() -> listOf(base.copy(url = url.trim(), title = url.trim()))
            else -> emptyList()
        }
        if (items.isEmpty()) return
        DownloadManager.enqueue(items)
        message = if (when0 > 0) ctx.getString(
            R.string.scheduled_at, java.text.DateFormat.getDateTimeInstance().format(java.util.Date(when0))
        ) else ctx.getString(R.string.added)
    }

    fun importTxt(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val lines = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readLines().orEmpty()
                .map { it.trim() }.filter { it.isNotEmpty() }
            val sel = if (selector.contains("height")) selector else ""
            val base = baseItem(0).copy(selector = sel, noPlaylist = false)
            val items = lines.map { l ->
                val u = if (l.startsWith("http")) l else "ytsearch1:$l"
                base.copy(url = u, title = l)
            }
            if (items.isNotEmpty()) {
                DownloadManager.enqueue(items)
                message = ctx.getString(R.string.added)
            }
        }
    }

    // ---- Templates ----
    fun saveTemplate(t: Template) { viewModelScope.launch(Dispatchers.IO) { db.templates().save(t) } }
    fun deleteTemplate(t: Template) { viewModelScope.launch(Dispatchers.IO) { db.templates().delete(t.id) } }

    fun exportTemplates(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val arr = JSONArray()
            templates.value.forEach { arr.put(JSONObject().put("name", it.name).put("content", it.content)) }
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(arr.toString(2).toByteArray()) }
            message = ctx.getString(R.string.templates_saved)
        }
    }

    fun importTemplates(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val txt = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
                val arr = JSONArray(txt)
                for (k in 0 until arr.length()) {
                    val o = arr.getJSONObject(k)
                    db.templates().save(Template(name = o.getString("name"), content = o.getString("content")))
                }
                message = ctx.getString(R.string.templates_saved)
            } catch (e: Exception) {
                message = ctx.getString(R.string.error_prefix) + (e.message ?: "")
            }
        }
    }

    // ---- Terminal ----
    val termLines = mutableStateListOf<String>()
    var termRunning by mutableStateOf(false)
    private var termJob: Job? = null

    fun runTerminal(args: String) {
        if (termRunning || args.isBlank()) return
        termRunning = true
        termLines.clear()
        termJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                Ytdlp.awaitReady()
                val r = YoutubeDLRequest(emptyList<String>())
                Ytdlp.applyTokens(r, Ytdlp.tokenize(args))
                val c = Ytdlp.cookiesFile(ctx)
                if (c.exists() && c.length() > 0) r.addOption("--cookies", c.absolutePath)
                val resp = YoutubeDL.getInstance().execute(r, TERM_PID) { _, _, line ->
                    termLines.add(line)
                    if (termLines.size > 2000) termLines.removeAt(0)
                }
                if (termLines.isEmpty()) termLines.addAll(resp.out.lines())
            } catch (e: Exception) {
                termLines.add((ctx.getString(R.string.error_prefix) + (e.message ?: e.toString())).takeLast(1500))
            }
            termRunning = false
        }
    }

    fun stopTerminal() {
        viewModelScope.launch(Dispatchers.IO) { YoutubeDL.getInstance().destroyProcessById(TERM_PID) }
    }

    // ---- Settings ----
    fun importCookies(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                Ytdlp.cookiesFile(ctx).outputStream().use { input.copyTo(it) }
            }
            message = ctx.getString(R.string.cookies_saved)
        }
    }

    fun clearCookies() {
        Ytdlp.cookiesFile(ctx).delete()
        message = ctx.getString(R.string.cookies_cleared)
    }

    fun updateYtdlp() {
        viewModelScope.launch(Dispatchers.IO) {
            message = ctx.getString(R.string.updating)
            try {
                Ytdlp.awaitReady()
                val s = YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.STABLE)
                message = ctx.getString(R.string.update_done) + " " + (s?.toString() ?: "")
            } catch (e: Exception) {
                message = ctx.getString(R.string.error_prefix) + (e.message ?: e.toString())
            }
        }
    }

    companion object { private const val TERM_PID = "terminal" }
}
