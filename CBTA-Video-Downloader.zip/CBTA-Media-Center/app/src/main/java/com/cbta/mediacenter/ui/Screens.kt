package com.cbta.mediacenter.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.cbta.mediacenter.R
import com.cbta.mediacenter.core.DownloadManager
import com.cbta.mediacenter.core.MediaInfo
import com.cbta.mediacenter.core.Storage
import com.cbta.mediacenter.data.*
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

// ---------- shared widgets ----------

@Composable
fun Picker(label: String, options: List<Pair<String, String>>, value: String, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val shown = options.firstOrNull { it.first == value }?.second ?: options.firstOrNull()?.second ?: ""
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: $shown", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (v, l) ->
                DropdownMenuItem(text = { Text(l) }, onClick = { onChange(v); open = false })
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().toggleable(value = checked, role = Role.Switch, onValueChange = onChange)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = null)
    }
}

fun pickDateTime(ctx: Context, onPicked: (Long) -> Unit) {
    val c = Calendar.getInstance()
    DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, min ->
            val t = Calendar.getInstance().apply { set(y, m, d, h, min, 0); set(Calendar.MILLISECOND, 0) }
            onPicked(t.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
}

@Composable
private fun InfoCard(info: MediaInfo) {
    Card(Modifier.fillMaxWidth().semantics(mergeDescendants = true) {}) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (info.thumb.isNotBlank()) {
                AsyncImage(
                    model = info.thumb, contentDescription = null,
                    modifier = Modifier.width(112.dp).height(64.dp), contentScale = ContentScale.Crop
                )
            }
            Column(Modifier.weight(1f)) {
                Text(info.title, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (info.author.isNotBlank()) Text(info.author, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ---------- Home ----------

@Composable
fun HomeScreen(vm: MainVM) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val templates by vm.templates.collectAsStateWithLifecycle()
    val pickTxt = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.importTxt(u)
    }
    val info = vm.info
    val canGo = vm.url.isNotBlank() && !(info?.isPlaylist == true && vm.selected.isEmpty())

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            OutlinedTextField(
                value = vm.url, onValueChange = { vm.url = it },
                label = { Text(stringResource(R.string.hint_link)) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.fetch() })
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { clip.getText()?.text?.let { vm.url = it.trim() } }) {
                    Text(stringResource(R.string.paste))
                }
                Button(onClick = { vm.fetch() }, enabled = !vm.loading && vm.url.isNotBlank()) {
                    Text(stringResource(R.string.fetch))
                }
            }
        }
        item {
            OutlinedButton(onClick = { pickTxt.launch(arrayOf("text/plain")) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.import_txt))
            }
        }
        item { SwitchRow(stringResource(R.string.single_only), vm.noPlaylist) { vm.noPlaylist = it } }

        if (vm.loading) item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(Modifier.size(24.dp))
                Text(stringResource(R.string.fetching))
            }
        }
        vm.error?.let { err ->
            item { Text(stringResource(R.string.error_prefix) + err, color = MaterialTheme.colorScheme.error) }
        }
        if (info != null && !info.isPlaylist) item { InfoCard(info) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    TYPE_AUDIO to R.string.type_audio,
                    TYPE_VIDEO to R.string.type_video,
                    TYPE_COMMAND to R.string.type_command
                ).forEach { (t, r) ->
                    FilterChip(
                        selected = vm.type == t,
                        onClick = { vm.type = t; vm.selector = "" },
                        label = { Text(stringResource(r)) }
                    )
                }
            }
        }

        when (vm.type) {
            TYPE_AUDIO -> {
                item {
                    Picker(
                        stringResource(R.string.audio_format),
                        listOf("mp3", "m4a", "opus", "aac", "flac", "wav", "best").map { it to it },
                        vm.audioFormat
                    ) { vm.audioFormat = it }
                }
                item { Picker(stringResource(R.string.quality), vm.qualityOptions(), vm.selector) { vm.selector = it } }
                item { SwitchRow(stringResource(R.string.embed_thumb), vm.embedThumb) { vm.embedThumb = it } }
            }
            TYPE_VIDEO -> {
                item { Picker(stringResource(R.string.quality), vm.qualityOptions(), vm.selector) { vm.selector = it } }
                item {
                    Picker(
                        stringResource(R.string.container),
                        listOf("mp4", "mkv", "webm").map { it to it }, vm.container
                    ) { vm.container = it }
                }
                item { SwitchRow(stringResource(R.string.embed_subs), vm.embedSubs) { vm.embedSubs = it } }
                item { SwitchRow(stringResource(R.string.embed_thumb), vm.embedThumb) { vm.embedThumb = it } }
                item { SwitchRow(stringResource(R.string.split_chapters), vm.split) { vm.split = it } }
            }
            else -> {
                item {
                    Picker(
                        stringResource(R.string.template),
                        listOf("" to stringResource(R.string.none_option)) + templates.map { it.content to it.name },
                        vm.command
                    ) { vm.command = it }
                }
                item {
                    OutlinedTextField(
                        value = vm.command, onValueChange = { vm.command = it },
                        label = { Text(stringResource(R.string.custom_args)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (info != null && info.isPlaylist) {
            item {
                Column {
                    Text(stringResource(R.string.playlist_found, info.entries.size), fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { vm.selected.clear(); vm.selected.addAll(info.entries.indices) }) {
                            Text(stringResource(R.string.select_all))
                        }
                        TextButton(onClick = { vm.selected.clear() }) { Text(stringResource(R.string.select_none)) }
                    }
                }
            }
            itemsIndexed(info.entries) { i, e ->
                val checked = i in vm.selected
                Row(
                    Modifier.fillMaxWidth().toggleable(
                        value = checked, role = Role.Checkbox,
                        onValueChange = { on -> if (on) vm.selected.add(i) else vm.selected.remove(i) }
                    ).padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = checked, onCheckedChange = null)
                    Spacer(Modifier.width(8.dp))
                    Text(e.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        item {
            Button(onClick = { vm.queue(0) }, enabled = canGo, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.download_now))
            }
        }
        item {
            OutlinedButton(
                onClick = { pickDateTime(ctx) { vm.queue(it) } }, enabled = canGo,
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.schedule)) }
        }
    }
}

// ---------- Downloads ----------

@Composable
private fun statusText(it: DownloadItem): String = when (it.status) {
    ST_QUEUED -> stringResource(R.string.st_queued)
    ST_RUNNING -> stringResource(R.string.st_running)
    ST_DONE -> stringResource(R.string.st_done)
    ST_ERROR -> stringResource(R.string.st_error)
    ST_CANCELLED -> stringResource(R.string.st_cancelled)
    else -> stringResource(R.string.st_scheduled) + " " +
        DateFormat.getDateTimeInstance().format(Date(it.scheduledAt))
}

@Composable
fun DownloadsScreen(vm: MainVM) {
    val all by vm.downloads.collectAsStateWithLifecycle()
    val prog by DownloadManager.progress.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    val activeStates = listOf(ST_QUEUED, ST_RUNNING, ST_SCHEDULED)
    val active = all.filter { it.status in activeStates }
    val history = all.filter { it.status !in activeStates }
    val list = if (tab == 0) active else history

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 },
                text = { Text(stringResource(R.string.tab_active) + " (${active.size})") })
            Tab(selected = tab == 1, onClick = { tab = 1 },
                text = { Text(stringResource(R.string.tab_history) + " (${history.size})") })
        }
        if (tab == 1 && history.isNotEmpty()) {
            TextButton(onClick = { DownloadManager.clearFinished() }, modifier = Modifier.padding(horizontal = 8.dp)) {
                Text(stringResource(R.string.clear_history))
            }
        }
        if (list.isEmpty()) {
            Text(stringResource(R.string.no_items), Modifier.padding(16.dp))
        }
        LazyColumn(
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.id }) { d -> DownloadRow(d, prog[d.id]) }
        }
    }
}

@Composable
private fun DownloadRow(d: DownloadItem, p: com.cbta.mediacenter.core.Prog?) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(d.title.ifBlank { d.url }, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val pct = p?.percent ?: 0
            Text(statusText(d) + if (d.status == ST_RUNNING) " — $pct%" else "")
            if (d.status == ST_RUNNING) {
                LinearProgressIndicator(
                    progress = { pct / 100f },
                    modifier = Modifier.fillMaxWidth().semantics { contentDescription = "$pct%" }
                )
            }
            if (d.status == ST_ERROR && d.log.isNotBlank()) {
                Text(d.log, maxLines = 4, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                when (d.status) {
                    ST_QUEUED, ST_RUNNING, ST_SCHEDULED ->
                        TextButton(onClick = { DownloadManager.cancel(d.id) }) { Text(stringResource(R.string.cancel)) }
                    ST_ERROR, ST_CANCELLED ->
                        TextButton(onClick = { DownloadManager.retry(d.id) }) { Text(stringResource(R.string.retry)) }
                    ST_DONE -> {
                        TextButton(onClick = { Storage.open(ctx, d) }) { Text(stringResource(R.string.open)) }
                        TextButton(onClick = { Storage.share(ctx, d) }) { Text(stringResource(R.string.share)) }
                    }
                    else -> {}
                }
                if (d.status != ST_RUNNING) {
                    TextButton(onClick = { DownloadManager.remove(d.id) }) { Text(stringResource(R.string.remove)) }
                }
            }
        }
    }
}

// ---------- Templates ----------

@Composable
fun TemplatesScreen(vm: MainVM) {
    val list by vm.templates.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<Template?>(null) }
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) vm.exportTemplates(u)
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.importTemplates(u)
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Button(onClick = { editing = Template(name = "", content = "") }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.add))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exp.launch("cbta-templates.json") }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.export_t))
                }
                OutlinedButton(onClick = { imp.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.import_t))
                }
            }
        }
        if (list.isEmpty()) item { Text(stringResource(R.string.no_items)) }
        items(list, key = { it.id }) { t ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(t.name, fontWeight = FontWeight.Bold)
                    Text(t.content, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton(onClick = { editing = t }) { Text(stringResource(R.string.edit)) }
                        TextButton(onClick = { vm.deleteTemplate(t) }) { Text(stringResource(R.string.remove)) }
                    }
                }
            }
        }
    }

    editing?.let { t ->
        var name by remember(t) { mutableStateOf(t.name) }
        var content by remember(t) { mutableStateOf(t.content) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(stringResource(R.string.template)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.name)) })
                    OutlinedTextField(content, { content = it }, label = { Text(stringResource(R.string.content)) })
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { vm.saveTemplate(t.copy(name = name.trim(), content = content.trim())); editing = null },
                    enabled = name.isNotBlank()
                ) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

// ---------- Terminal ----------

@Composable
fun TerminalScreen(vm: MainVM) {
    val clip = LocalClipboardManager.current
    var args by remember { mutableStateOf("") }
    val state = rememberLazyListState()
    LaunchedEffect(vm.termLines.size) {
        if (vm.termLines.isNotEmpty()) state.scrollToItem(vm.termLines.size - 1)
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = args, onValueChange = { args = it },
            label = { Text(stringResource(R.string.custom_args)) },
            placeholder = { Text(stringResource(R.string.args_hint)) },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.runTerminal(args) }, enabled = !vm.termRunning && args.isNotBlank()) {
                Text(stringResource(R.string.run))
            }
            OutlinedButton(onClick = { vm.stopTerminal() }, enabled = vm.termRunning) {
                Text(stringResource(R.string.stop))
            }
            OutlinedButton(
                onClick = { clip.setText(AnnotatedString(vm.termLines.joinToString("\n"))) },
                enabled = vm.termLines.isNotEmpty()
            ) { Text(stringResource(R.string.copy)) }
        }
        if (vm.termRunning) LinearProgressIndicator(Modifier.fillMaxWidth())
        SelectionContainer(Modifier.weight(1f)) {
            LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
                items(vm.termLines.toList()) { line ->
                    Text(line, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen(vm: MainVM) {
    val ctx = LocalContext.current
    val p = vm.prefs
    var max by remember { mutableIntStateOf(p.maxConcurrent) }
    var frag by remember { mutableIntStateOf(p.fragments) }
    var aria by remember { mutableStateOf(p.useAria) }
    var tpl by remember { mutableStateOf(p.nameTemplate) }
    var subs by remember { mutableStateOf(p.subLangs) }
    var tree by remember { mutableStateOf(p.treeUri) }

    val cookies = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.importCookies(u)
    }
    val folder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            ctx.contentResolver.takePersistableUriPermission(
                u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            p.treeUri = u.toString(); tree = u.toString()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Picker(stringResource(R.string.set_concurrent), (1..5).map { "$it" to "$it" }, "$max") {
            max = it.toInt(); p.maxConcurrent = max
        }
        Picker(stringResource(R.string.set_fragments), listOf(1, 2, 4, 8, 16).map { "$it" to "$it" }, "$frag") {
            frag = it.toInt(); p.fragments = frag
        }
        SwitchRow(stringResource(R.string.set_aria), aria) { aria = it; p.useAria = it }
        OutlinedTextField(
            value = tpl, onValueChange = { tpl = it; p.nameTemplate = it },
            label = { Text(stringResource(R.string.set_template)) }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = subs, onValueChange = { subs = it; p.subLangs = it },
            label = { Text(stringResource(R.string.set_sublangs)) }, modifier = Modifier.fillMaxWidth()
        )
        Text(stringResource(R.string.set_folder_current, tree?.let { android.net.Uri.parse(it).lastPathSegment } ?: "Downloads/CBTA Media Center"))
        OutlinedButton(onClick = { folder.launch(null) }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_folder))
        }
        OutlinedButton(onClick = { p.treeUri = null; tree = null }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_folder_reset))
        }
        OutlinedButton(onClick = { cookies.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_cookies))
        }
        OutlinedButton(onClick = { vm.clearCookies() }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_cookies_clear))
        }
        Button(onClick = { vm.updateYtdlp() }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_update))
        }
        Text(stringResource(R.string.about), style = MaterialTheme.typography.bodySmall)
    }
}
