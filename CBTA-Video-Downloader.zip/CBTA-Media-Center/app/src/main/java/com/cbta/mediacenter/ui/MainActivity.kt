package com.cbta.mediacenter.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.cbta.mediacenter.R

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)

        handleIntent(intent)
        setContent { AppTheme { Root(vm) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        vm.url = Regex("https?://\\S+").find(t)?.value ?: t.trim()
        vm.tab = 0
        vm.fetch()
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root(vm: MainVM) {
    val host = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let { host.showSnackbar(it); vm.message = null }
    }
    val tabs = listOf(
        Triple(R.string.nav_home, Icons.Default.Home, 0),
        Triple(R.string.nav_downloads, Icons.Default.List, 1),
        Triple(R.string.nav_templates, Icons.Default.Edit, 2),
        Triple(R.string.nav_terminal, Icons.Default.Build, 3),
        Triple(R.string.nav_settings, Icons.Default.Settings, 4)
    )
    Scaffold(
        snackbarHost = { SnackbarHost(host) },
        bottomBar = {
            NavigationBar {
                tabs.forEach { (label, icon, idx) ->
                    NavigationBarItem(
                        selected = vm.tab == idx,
                        onClick = { vm.tab = idx },
                        icon = { Icon(icon, contentDescription = null) },
                        label = { Text(stringResource(label), maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (vm.tab) {
                0 -> HomeScreen(vm)
                1 -> DownloadsScreen(vm)
                2 -> TemplatesScreen(vm)
                3 -> TerminalScreen(vm)
                else -> SettingsScreen(vm)
            }
        }
    }
}
