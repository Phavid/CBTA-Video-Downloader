package com.cbta.mediacenter

import android.app.Application
import com.cbta.mediacenter.core.DownloadManager
import com.cbta.mediacenter.core.Notifier
import com.cbta.mediacenter.core.Ytdlp
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlin.concurrent.thread

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        DownloadManager.init(this)
        Notifier.ensureChannels(this)
        // First launch unpacks Python/FFmpeg, so do it off the main thread.
        thread(name = "ytdl-init") {
            try {
                YoutubeDL.getInstance().init(this)
                FFmpeg.getInstance().init(this)
                Aria2c.getInstance().init(this)
                Ytdlp.markReady(null)
            } catch (t: Throwable) {
                Ytdlp.markReady(t.message ?: t.toString())
            }
        }
    }
}
