# CBTA Media Center — Phase 1 Scope

## Product goal
Build a reliable, privacy-conscious, bilingual and TalkBack-friendly Android media center for blind, low-vision and sighted users. The first phase establishes a working foundation that can be tested on real phones before advanced features are added.

## Phase 1 included
- Add direct media URL by paste or Android Share intent.
- Validate HTTP/HTTPS links and explain unsupported page URLs.
- Open YouTube only through the official app/browser; no extraction, scraping, DRM circumvention or unauthorized downloading.
- Inspect server redirects, MIME type and Content-Disposition filename when HEAD is supported.
- Download permitted direct media using Android DownloadManager.
- Multiple simultaneous downloads are handled by Android DownloadManager; in-app list shows state, percentage and bytes when available.
- Cancel/remove download.
- Preview supported network media with Media3.
- Open local media with Android document picker and play it.
- Completed-download library view.
- Khmer/English language toggle.
- TalkBack-friendly named controls, labels and logical reading order.
- Preferred audio output for CBTA playback: automatic, phone speaker, and currently available Bluetooth/wired/USB/HDMI output devices; persist selection and fall back to default if device disappears.
- Privacy baseline: no account, no telemetry, no CBTA server storing link or media history, and no broad storage permission.

## Explicitly deferred
- Conversion/transcoding to MP3 or WAV.
- Pause/resume of active downloads, retry policy and advanced queue ordering.
- Background audio playback service and lock-screen/media notification controls.
- Playlists, shuffle, repeat, sleep timer, playback speed and equalizer.
- Full device media scanner, search, sorting, duplicate detection, folders and metadata editor.
- Trim/crop/extract audio, waveform editor and volume normalization.
- QR, Bluetooth/Wi-Fi file transfer, SMB, NAS, WebDAV and cloud sync.
- PiP, home-screen widget, voice commands and optional AI assistant.
- Backup/restore and detailed storage cleanup.

These are not rejected ideas. They remain in the master roadmap and should be prioritized only after the Phase 1 test results and community feedback.

## Acceptance tests
1. App opens without crashing on the target Android device.
2. TalkBack announces every navigation item, input, format-independent download action and player control by a meaningful name; no unlabeled numeric controls.
3. Share a valid direct media link from a browser or messaging app into CBTA; it appears in the URL field.
4. A permitted direct MP4/audio URL queues a download; progress/status and file size display when the server provides them.
5. Redirected links and Content-Disposition filenames are handled where the server supports HEAD.
6. A normal HTML page is rejected with an understandable message.
7. YouTube opens only in the official app/browser; no standalone download is attempted.
8. Completed downloads appear in Library and can be opened in the player.
9. Local audio/video can be selected with Android's file picker and played.
10. With Bluetooth connected, CBTA can request Bluetooth output; test whether TalkBack remains audible on the phone speaker. This outcome is device/OS-dependent and must be recorded, not assumed.
11. When the selected Bluetooth output disconnects, CBTA falls back to system default without crashing.
12. Khmer and English labels are understandable with TalkBack.
13. No login/account is required and no media history is transmitted to a CBTA server.

## Release gate
Phase 1 is not considered complete just because the APK builds. It must pass the GitHub build, install safely, and complete the real-device accessibility, download, playback and audio-routing tests. Fix failures before starting Phase 2.
