# CBTA Media Center — Master Roadmap

## Vision
A free-first, accessible Android media center designed with blind and low-vision users from the beginning while remaining comfortable for sighted users. Core functions should work without an account. Keep data local, request permissions only when needed, and develop in testable increments.

## Phase 1 — Foundation (current)
Direct authorized downloads, Share-to-CBTA, Khmer/English, TalkBack-first UI, Media3 preview/player, completed-download library, DownloadManager progress/cancel, and preferred CBTA audio output selection. See `PHASE1_SCOPE.md`.

## Phase 2 — Download and library management
- Persistent download queue with pause/resume where the server supports HTTP Range.
- Cancel, retry after network recovery, retry limits and clear error messages.
- Wi-Fi-only option, metered-network warning, battery-aware scheduling and configurable concurrency.
- Duplicate detection, download history, rename, delete confirmation, share-out, search, sorting and filters.
- Better filename/MIME/metadata handling and source compatibility diagnostics.
- Storage usage view and user-controlled history cleanup/export.

## Phase 3 — Player and accessibility expansion
- Foreground/background audio playback service.
- Lock-screen and notification playback controls.
- Resume last position, seek, playback speed, repeat, shuffle, playlists and sleep timer.
- Headphone/Bluetooth controls, audio focus handling, route-change announcements and more complete preferred-output testing.
- PiP for video where supported; optional home-screen widget.
- Adjustable text size, contrast themes, stronger TalkBack focus testing and accessibility feedback.

## Phase 4 — Media conversion and editing
- Import local files.
- Convert video to MP3/WAV and audio between supported formats using legally compliant, properly licensed libraries/codecs.
- Choose quality/bitrate/sample rate where technically supported.
- Preserve the original source by default.
- Trim audio/video, extract audio, adjust volume and add a simple waveform/timeline.
- Clearly explain codec, device and storage limitations before conversion.

## Phase 5 — Sharing and advanced media management
- Android Share-out, QR-based transfer, Bluetooth and local Wi-Fi transfer.
- Optional LAN integrations such as SMB, NAS and WebDAV after security review.
- Folder management, metadata, duplicate scanning and storage cleanup tools.
- Backup/restore with explicit user control and encryption where appropriate.

## Phase 6 — Smart assistance and ecosystem
- Optional voice commands, only where language recognition quality is adequate.
- Optional AI helper to explain errors, app use and media metadata; no mandatory cloud dependency.
- Optional recommendations and accessibility guidance.
- Broader device compatibility and community-driven improvements.

## Permanent principles
1. Test each phase on real devices before advancing.
2. TalkBack accessibility is a release requirement, not a later decoration.
3. Never claim a feature works until verified.
4. Preserve the application ID `com.cbta.videodownloader` and increase versionCode for updates.
5. Use stable app signing for future in-place updates; do not commit private keystores or passwords to the public repository.
6. Respect copyright, website terms, DRM and source permissions. YouTube uses official playback/download functionality only.
7. Keep logs free of private URLs, tokens and personal file names unless the user explicitly chooses to export a diagnostic report.
8. Collect community feedback and rank features by usefulness, accessibility, feasibility, reliability and cost.
