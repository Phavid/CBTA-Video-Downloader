CBTA MEDIA CENTER — PHASE 1
==========================

Project folder: CBTA-Video-Downloader
Android application ID: com.cbta.videodownloader
Version name: 1.3
Version code: 4
Minimum Android: 7.0 (API 24)
Compile/Target SDK: 35
Language: Kotlin + Jetpack Compose
Playback: AndroidX Media3 ExoPlayer 1.8.0
Build: GitHub Actions, Java 17, Gradle 8.9

PHASE 1 FEATURES
-----------------
1. Khmer / English interface.
2. Share a text link from another Android app into CBTA.
3. Paste and validate HTTP/HTTPS links.
4. Open YouTube links in the official YouTube app/browser. CBTA does not download YouTube content or bypass restrictions.
5. Inspect direct media URLs using HTTP HEAD when supported, including redirects, MIME type and Content-Disposition filename.
6. Queue permitted direct downloads through Android DownloadManager. Downloads continue in the background under Android's download service.
7. View status, progress and file sizes; cancel/remove a download.
8. Play supported direct media streams and downloaded files with Media3.
9. Open a local audio/video file through Android's document picker.
10. Basic library view of completed downloads.
11. TalkBack-oriented labels, named controls and a simple navigation order.
12. Preferred audio output selection for CBTA playback: system default, phone speaker and available wired/Bluetooth/USB outputs. Android may not honor a preferred device on every model. This does not control TalkBack's own output route.
13. No mandatory account and no CBTA analytics/server upload of media history.

IMPORTANT LIMITS IN PHASE 1
---------------------------
- Downloads are for direct media links that the user is authorized to access.
- A web page URL is not necessarily a media file URL.
- MP4/MP3/WAV conversion is NOT included yet. The app preserves the original media format returned by the source; it does not merely rename files.
- Pause/resume, automatic retry, advanced queue management, background playback, notification playback controls, playlists, search, duplicate detection, trimming, equalizer and file conversion are future-phase features.
- The audio output selector requests a preferred route for CBTA's ExoPlayer stream. It cannot force TalkBack to remain on the phone speaker. Actual behavior must be tested on real devices and depends on Android/manufacturer routing.
- On Android 9 and earlier, the app requests legacy storage permission only when it is needed to save to the public Downloads folder. Newer Android versions do not receive this broad storage permission.
- The app has not been certified as compiled or tested on the user's phone merely by creating this source archive. GitHub Actions build and real-device TalkBack testing are required.

BUILD
-----
The repository's existing .github/workflows/android-build.yml expects this archive at the repository root with the exact name:
CBTA-Video-Downloader.zip

It extracts the archive, finds settings.gradle.kts, runs:
gradle assembleDebug

and uploads the APK as a GitHub Actions artifact.

VERSION / INSTALLATION WARNING
------------------------------
The installed v1.2 APK was built using an ephemeral GitHub Actions debug signing key. A later GitHub Actions run may use a different key. Android can reject an update signed with a different key. Do not uninstall the currently installed app until a new APK has successfully built and the signing/migration plan has been checked. This source archive currently retains the same application ID and increases versionCode to 4.

NEXT STEPS
----------
1. Upload this ZIP to the repository root, replacing the previous CBTA-Video-Downloader.zip.
2. Let GitHub Actions build it.
3. Inspect build logs and APK artifact; do not assume success before GitHub confirms it.
4. Install/test only after checking the signing compatibility warning.
5. Test TalkBack, link sharing, direct downloads, local playback, Bluetooth output and Bluetooth disconnect fallback.
6. Collect community feedback and prioritize fixes before Phase 2.
