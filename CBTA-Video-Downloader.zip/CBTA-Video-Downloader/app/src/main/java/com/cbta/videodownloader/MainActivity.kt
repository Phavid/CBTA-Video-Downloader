
package com.cbta.videodownloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.net.URLDecoder
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var sharedLink by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedLink = readSharedText(intent)

        showApp()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedLink = readSharedText(intent)
    }

    private fun readSharedText(source: Intent?): String {
        if (
            source?.action == Intent.ACTION_SEND &&
            source.type?.startsWith("text/") == true
        ) {
            return source.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        }

        return ""
    }

    private fun showApp() {
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DownloaderScreen(sharedLink = sharedLink)
                }
            }
        }
    }
}

private enum class DownloadFormat(
    val extension: String,
    val mimeType: String
) {
    MP4("mp4", "video/mp4"),
    MP3("mp3", "audio/mpeg"),
    WAV("wav", "audio/wav")
}

@androidx.compose.runtime.Composable
private fun DownloaderScreen(sharedLink: String) {

    val context = LocalContext.current

    var url by remember { mutableStateOf(sharedLink) }

    var selectedFormat by remember {
        mutableStateOf(DownloadFormat.MP4)
    }

    var isKhmer by remember { mutableStateOf(true) }

    var status by remember { mutableStateOf("") }

    LaunchedEffect(sharedLink) {
        if (sharedLink.isNotBlank()) {
            url = sharedLink.trim()
        }
    }

    val title = if (isKhmer)
        "CBTA កម្មវិធីទាញយកវីដេអូ"
    else
        "CBTA Video Downloader"

    val instruction = if (isKhmer)
        "បញ្ចូលតំណភ្ជាប់ឯកសារមេឌៀផ្ទាល់ដែលអ្នកមានសិទ្ធិទាញយក"
    else
        "Paste a direct media-file link that you are allowed to download."

    val linkLabel = if (isKhmer) "តំណភ្ជាប់" else "Media URL"

    val formatLabel = if (isKhmer)
        "ជ្រើសរើសទម្រង់ឯកសារ"
    else
        "Choose file format"

    val downloadLabel = if (isKhmer)
        "ចាប់ផ្តើមទាញយក"
    else
        "Start download"

    val clearLabel = if (isKhmer) "សម្អាត" else "Clear"

    val note = if (isKhmer)
        "ចំណាំ៖ កំណែនេះទាញយកតែតំណភ្ជាប់ឯកសារ MP4, MP3 ឬ WAV ផ្ទាល់ប៉ុណ្ណោះ។ វាមិនអាចទាញយកពីគ្រប់គេហទំព័រ ឬបម្លែងវីដេអូទៅជាសំឡេងបានទេ។"
    else
        "Note: This version downloads direct MP4, MP3, or WAV file links only. It does not support every website or convert video into audio."

    val statusLabel = if (isKhmer) "ស្ថានភាព៖ " else "Status: "

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.Top
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(
                onClick = { isKhmer = !isKhmer }
            ) {
                Text(if (isKhmer) "English" else "ភាសាខ្មែរ")
            }
        }

        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(instruction)

        Spacer(modifier = Modifier.height(18.dp))

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(linkLabel) },
            placeholder = { Text("https://example.com/video.mp4") },
            minLines = 3,
            maxLines = 5
        )

        Spacer(modifier = Modifier.height(18.dp))

        Text(formatLabel, fontWeight = FontWeight.Bold)

        DownloadFormat.values().forEach { format ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                RadioButton(
                    selected = selectedFormat == format,
                    onClick = { selectedFormat = format }
                )

                Text(
                    text = format.name,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
            onClick = {
                status = startDownload(
                    context = context,
                    rawUrl = url,
                    format = selectedFormat,
                    isKhmer = isKhmer
                )

                Toast.makeText(
                    context,
                    status,
                    Toast.LENGTH_LONG
                ).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(downloadLabel)
        }

        TextButton(
            onClick = {
                url = ""
                status = ""
            },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text(clearLabel)
        }

        if (status.isNotBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(statusLabel + status)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            note,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

private fun startDownload(
    context: Context,
    rawUrl: String,
    format: DownloadFormat,
    isKhmer: Boolean
): String {

    fun message(kh: String, en: String): String {
        return if (isKhmer) kh else en
    }

    val cleanUrl = rawUrl.trim()

    if (cleanUrl.isEmpty()) {
        return message(
            "សូមបញ្ចូលតំណភ្ជាប់ជាមុនសិន។",
            "Please enter a URL first."
        )
    }

    val uri = try {
        Uri.parse(cleanUrl)
    } catch (_: Exception) {
        return message(
            "តំណភ្ជាប់មិនត្រឹមត្រូវទេ។",
            "The URL is invalid."
        )
    }

    if (
        uri.scheme !in listOf("http", "https") ||
        uri.host.isNullOrBlank()
    ) {
        return message(
            "សូមប្រើតំណភ្ជាប់ដែលចាប់ផ្តើមដោយ http:// ឬ https://។",
            "Use a valid http:// or https:// URL."
        )
    }

    val path = uri.lastPathSegment
        .orEmpty()
        .lowercase(Locale.ROOT)

    if (!path.endsWith(".${format.extension}")) {
        return message(
            "ទម្រង់តំណភ្ជាប់មិនត្រូវនឹង ${format.name} ដែលបានជ្រើសរើសទេ។ សូមជ្រើសទម្រង់ត្រឹមត្រូវ។",
            "The link does not end in .${format.extension}. Choose the matching format."
        )
    }

    return try {

        val decodedName = URLDecoder.decode(
            uri.lastPathSegment ?: "",
            "UTF-8"
        )

        val safeName = decodedName
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .ifBlank {
                "cbta_download.${format.extension}"
            }

        val request = DownloadManager.Request(uri)
            .setTitle(safeName)
            .setDescription("CBTA Video Downloader")
            .setMimeType(format.mimeType)
            .setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            .setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                safeName
            )
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)

        val manager = context.getSystemService(
            Context.DOWNLOAD_SERVICE
        ) as DownloadManager

        manager.enqueue(request)

        message(
            "បានដាក់សំណើទាញយកហើយ។ សូមពិនិត្យការជូនដំណឹង និងថត Downloads។",
            "Download queued. Check notifications and the Downloads folder."
        )

    } catch (error: Exception) {

        message(
            "មិនអាចចាប់ផ្តើមទាញយកបានទេ៖ ${error.message ?: "កំហុសមិនស្គាល់"}",
            "Could not start download: ${error.message ?: "Unknown error"}"
        )
    }
}

