@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.cbta.videodownloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.Executors
import java.util.regex.Pattern

private enum class Page { ADD, DOWNLOADS, PLAYER, LIBRARY, SETTINGS }
private data class DownloadEntry(val id: Long, val title: String, val status: String, val detail: String, val progress: Int)
private data class OutputChoice(val id: Int, val type: Int, val name: String, val device: AudioDeviceInfo?)

class MainActivity : ComponentActivity() {
    private var sharedText by mutableStateOf("")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedText = readSharedText(intent)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { CbtaMediaCenter(sharedText) } } }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedText = readSharedText(intent)
    }
    private fun readSharedText(intent: Intent?): String =
        if (intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("text/") == true)
            intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
}

@Composable
private fun CbtaMediaCenter(sharedText: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as? ComponentActivity
    val prefs = remember { context.getSharedPreferences("cbta_media_center", Context.MODE_PRIVATE) }
    var khmer by remember { mutableStateOf(prefs.getBoolean("khmer", true)) }
    var page by remember { mutableStateOf(Page.ADD) }
    var url by remember { mutableStateOf(sharedText) }
    var status by remember { mutableStateOf("") }
    var isBusy by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    var playerError by remember { mutableStateOf("") }
    var currentTitle by remember { mutableStateOf("") }
    var selectedOutputKey by remember { mutableStateOf(prefs.getString("output_key", "AUTO") ?: "AUTO") }
    var outputMessage by remember { mutableStateOf("") }
    var pendingDownload by remember { mutableStateOf("") }
    val player = remember(context) { ExoPlayer.Builder(context).build() }
    val downloads = remember { mutableStateListOf<DownloadEntry>() }
    val audioManager = remember(context) { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    fun beginDownload(clean: String) {
        isBusy = true
        status = if (khmer) "កំពុងពិនិត្យប្រភពមេឌៀ..." else "Checking media source..."
        executor.execute {
            val result = inspectAndQueue(context, clean, khmer)
            mainHandler.post { status = result; isBusy = false; refresh++ }
        }
    }

    val storagePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val target = pendingDownload
        pendingDownload = ""
        if (granted && target.isNotBlank()) beginDownload(target)
        else status = if (khmer) "មិនមានសិទ្ធិសរសេរទៅថត Downloads ទេ។ កម្មវិធីមិនបានចាប់ផ្ដើមទាញយកឡើយ។" else "Storage permission was not granted. The download was not started."
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                playerError = if (khmer) "មិនអាចចាក់ឯកសារនេះបានទេ។ សូមសាកល្បងឯកសារផ្សេង។" else "This media could not be played. Try another file."
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release(); executor.shutdown() }
    }

    LaunchedEffect(sharedText) { if (sharedText.isNotBlank()) { url = sharedText.trim(); page = Page.ADD } }
    LaunchedEffect(page, refresh) {
        if (page == Page.DOWNLOADS || page == Page.LIBRARY) {
            while (true) {
                loadDownloads(context, downloads)
                kotlinx.coroutines.delay(1200)
            }
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            currentTitle = uri.lastPathSegment?.substringAfterLast('/') ?: if (khmer) "ឯកសារដែលបានជ្រើស" else "Selected media"
            playerError = ""
            player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.playWhenReady = true
            page = Page.PLAYER
        }
    }

    val outputs = remember(refresh) { availableOutputs(audioManager) }
    val preferredOutput = outputs.firstOrNull { outputKey(it) == selectedOutputKey }?.device
    LaunchedEffect(selectedOutputKey, refresh) {
        if (selectedOutputKey == "AUTO") {
            player.setPreferredAudioDevice(null)
            outputMessage = if (khmer) "ប្រើឧបករណ៍បញ្ចេញសំឡេងលំនាំដើមរបស់ Android។" else "Using Android's default audio output."
        } else if (preferredOutput != null) {
            player.setPreferredAudioDevice(preferredOutput)
            outputMessage = if (khmer) "បានស្នើឱ្យប្រើ៖ ${outputs.first { outputKey(it) == selectedOutputKey }.name}" else "Requested output: ${outputs.first { outputKey(it) == selectedOutputKey }.name}"
        } else {
            player.setPreferredAudioDevice(null)
            selectedOutputKey = "AUTO"
            prefs.edit().putString("output_key", "AUTO").apply()
            outputMessage = if (khmer) "ឧបករណ៍ដែលបានជ្រើសមិនមានទៀតទេ។ បានត្រឡប់ទៅសំឡេងលំនាំដើម។" else "Selected device is unavailable. Returned to default output."
        }
    }
    DisposableEffect(audioManager) {
        val callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) { refresh++ }
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) { refresh++ }
        }
        audioManager.registerAudioDeviceCallback(callback, mainHandler)
        onDispose { audioManager.unregisterAudioDeviceCallback(callback) }
    }

    fun playUri(uri: Uri, title: String) {
        currentTitle = title
        playerError = ""
        player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.playWhenReady = true
        page = Page.PLAYER
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { khmer = !khmer; prefs.edit().putBoolean("khmer", khmer).apply() }) {
                Text(if (khmer) "English" else "ភាសាខ្មែរ")
            }
        }
        Text(if (khmer) "CBTA Media Center" else "CBTA Media Center", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(if (khmer) "មជ្ឈមណ្ឌលទាញយក គ្រប់គ្រង និងចាក់ឯកសារមេឌៀ" else "Download, organize and play your media", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            navButton(if (khmer) "បន្ថែម" else "Add", page == Page.ADD, Modifier.weight(1f)) { page = Page.ADD }
            navButton(if (khmer) "ទាញយក" else "Downloads", page == Page.DOWNLOADS, Modifier.weight(1f)) { page = Page.DOWNLOADS; refresh++ }
            navButton(if (khmer) "ចាក់" else "Player", page == Page.PLAYER, Modifier.weight(1f)) { page = Page.PLAYER }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            navButton(if (khmer) "បណ្ណាល័យ" else "Library", page == Page.LIBRARY, Modifier.weight(1f)) { page = Page.LIBRARY; refresh++ }
            navButton(if (khmer) "កំណត់" else "Settings", page == Page.SETTINGS, Modifier.weight(1f)) { page = Page.SETTINGS; refresh++ }
            Spacer(Modifier.weight(1f))
        }
        Divider(Modifier.padding(vertical = 10.dp))

        when (page) {
            Page.ADD -> {
                Text(if (khmer) "បន្ថែមតំណភ្ជាប់" else "Add a media link", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(if (khmer) "បិទភ្ជាប់តំណភ្ជាប់ឯកសារមេឌៀផ្ទាល់ ឬប្រើប៊ូតុង Share ពីកម្មវិធីផ្សេង។ ត្រូវប្រាកដថាអ្នកមានសិទ្ធិទាញយកឯកសារ។" else "Paste a direct media URL or use Share from another app. Make sure you have permission to download the file.")
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (khmer) "តំណភ្ជាប់មេឌៀ" else "Media URL") }, placeholder = { Text("https://example.com/video.mp4") }, minLines = 2, maxLines = 4)
                Spacer(Modifier.height(10.dp))
                Button(onClick = {
                    val clean = url.trim()
                    val uri = runCatching { Uri.parse(clean) }.getOrNull()
                    if (clean.isBlank() || uri == null || uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
                        status = if (khmer) "សូមបញ្ចូលតំណភ្ជាប់ HTTP ឬ HTTPS ដែលត្រឹមត្រូវ។" else "Enter a valid HTTP or HTTPS URL."
                    } else if (isYoutubeHost(uri.host.orEmpty())) {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)) }
                            .onSuccess { status = if (khmer) "បានបើកតំណក្នុង YouTube ឬកម្មវិធីរុករកផ្លូវការ។ ការទាញយក YouTube មិនត្រូវបានគាំទ្រទេ។" else "Opened in the official YouTube app or browser. YouTube downloading is not supported." }
                            .onFailure { status = if (khmer) "មិនអាចបើកតំណនេះបានទេ។" else "Could not open this link." }
                    } else {
                        if (Build.VERSION.SDK_INT in 23..28 && context.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            pendingDownload = clean
                            storagePermission.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        } else beginDownload(clean)
                    }
                }, enabled = !isBusy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (isBusy) (if (khmer) "កំពុងដំណើរការ..." else "Working...") else (if (khmer) "ចាប់ផ្ដើមទាញយក" else "Start download"))
                }
                OutlinedButton(onClick = {
                    val clean = url.trim(); val uri = runCatching { Uri.parse(clean) }.getOrNull()
                    if (uri != null && uri.scheme in listOf("http", "https") && uri.host != null) {
                        if (isYoutubeHost(uri.host.orEmpty())) {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                            status = if (khmer) "កំពុងបើកប្រភព YouTube ផ្លូវការ។" else "Opening the official YouTube source."
                        } else {
                            currentTitle = if (khmer) "មើលជាមុន" else "Preview"
                            playerError = ""; player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.playWhenReady = true; page = Page.PLAYER
                        }
                    } else status = if (khmer) "សូមបញ្ចូលតំណភ្ជាប់ត្រឹមត្រូវជាមុន។" else "Enter a valid URL first."
                }, modifier = Modifier.fillMaxWidth()) { Text(if (khmer) "មើល ឬស្ដាប់ជាមុន" else "Preview") }
                OutlinedButton(onClick = { url = ""; status = "" }, modifier = Modifier.fillMaxWidth()) { Text(if (khmer) "សម្អាតតំណភ្ជាប់" else "Clear link") }
                if (status.isNotBlank()) Text(status, Modifier.padding(top = 10.dp), color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp))
                Text(if (khmer) "ទម្រង់ឯកសារ៖ កម្មវិធីរក្សាទុកទម្រង់ដើមដែលម៉ាស៊ីនមេផ្ញើមក។ ការបម្លែងទៅ MP3 ឬ WAV នឹងបន្ថែមនៅដំណាក់កាលបន្ទាប់។" else "File format: The app keeps the original format supplied by the server. MP3/WAV conversion is planned for a later phase.")
                Text(if (khmer) "YouTube នឹងបើកក្នុងកម្មវិធី ឬកម្មវិធីរុករកផ្លូវការ។ កម្មវិធី CBTA មិនរំលងការការពារ ឬលក្ខខណ្ឌរបស់ YouTube ទេ។" else "YouTube links open in the official app or browser. CBTA does not bypass YouTube protections or terms.")
            }
            Page.DOWNLOADS, Page.LIBRARY -> {
                val libraryOnly = page == Page.LIBRARY
                Text(if (khmer) { if (libraryOnly) "បណ្ណាល័យឯកសារ" else "ការទាញយក" } else { if (libraryOnly) "Media library" else "Downloads" }, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (downloads.isEmpty()) Text(if (khmer) "មិនទាន់មានឯកសារទាញយកទេ។" else "No downloads yet.", Modifier.padding(vertical = 12.dp))
                downloads.filter { !libraryOnly || it.status == "COMPLETE" }.forEach { item ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(item.title, fontWeight = FontWeight.Bold)
                            Text(item.statusText(khmer))
                            if (item.progress in 0..99 && item.status == "RUNNING") Text("${item.progress}%")
                            if (item.detail.isNotBlank()) Text(item.detail)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (item.status == "COMPLETE") OutlinedButton(onClick = {
                                    val uri = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).getUriForDownloadedFile(item.id)
                                    if (uri != null) playUri(uri, item.title) else status = if (khmer) "មិនអាចបើកឯកសារនេះបានទេ។" else "Could not open this file."
                                }) { Text(if (khmer) "ចាក់ឯកសារ" else "Play") }
                                if (!libraryOnly) TextButton(onClick = {
                                    (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(item.id)
                                    refresh++
                                }) { Text(if (khmer) "លុប/បោះបង់" else "Remove/Cancel") }
                            }
                        }
                    }
                }
                Text(if (khmer) "ការទាញយកដំណើរការក្នុងផ្ទៃខាងក្រោយដោយប្រព័ន្ធ Android។ នៅជំនាន់នេះអាចបោះបង់បាន ប៉ុន្តែមុខងារ Pause/Resume នឹងត្រូវបន្ថែមក្រោយការសាកល្បង។" else "Downloads run in the Android background service. This phase supports cancel/remove; pause/resume will be added after testing.", Modifier.padding(top = 8.dp))
            }
            Page.PLAYER -> {
                Text(if (khmer) "កម្មវិធីចាក់មេឌៀ" else "Media player", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(if (currentTitle.isBlank()) (if (khmer) "មិនទាន់មានឯកសារកំពុងចាក់។" else "No media selected.") else currentTitle)
                Spacer(Modifier.height(8.dp))
                AndroidView(factory = { PlayerView(it).apply { player = player; useController = true; controllerAutoShow = true; contentDescription = if (khmer) "កម្មវិធីចាក់វីដេអូ និងសំឡេង" else "Video and audio player" } }, update = { it.player = player }, modifier = Modifier.fillMaxWidth().height(220.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (player.isPlaying) player.pause() else player.play() }, modifier = Modifier.weight(1f)) { Text(if (player.isPlaying) (if (khmer) "ផ្អាក" else "Pause") else (if (khmer) "ចាក់" else "Play")) }
                    OutlinedButton(onClick = { player.stop() }, modifier = Modifier.weight(1f)) { Text(if (khmer) "បញ្ឈប់" else "Stop") }
                }
                Button(onClick = { filePicker.launch(arrayOf("audio/*", "video/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (khmer) "បើកឯកសារពីទូរសព្ទ" else "Open media from phone") }
                if (playerError.isNotBlank()) Text(playerError, color = MaterialTheme.colorScheme.error)
                Text(if (khmer) "ការចាក់នៅក្នុងដំណាក់កាលនេះផ្តោតលើការប្រើកម្មវិធីនៅខាងមុខ។ ការចាក់សំឡេងពេលបិទអេក្រង់ និង Notification Controls នឹងត្រូវបន្ថែមនៅដំណាក់កាលបន្ទាប់។" else "This phase focuses on foreground playback. Background playback and notification controls are planned for a later phase.")
            }
            Page.SETTINGS -> {
                Text(if (khmer) "ការកំណត់" else "Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(if (khmer) "ភាសា" else "Language", fontWeight = FontWeight.Bold)
                TextButton(onClick = { khmer = !khmer; prefs.edit().putBoolean("khmer", khmer).apply() }) { Text(if (khmer) "ប្ដូរទៅ English" else "ប្ដូរទៅភាសាខ្មែរ") }
                Divider(Modifier.padding(vertical = 8.dp))
                Text(if (khmer) "ជ្រើសរើសឧបករណ៍បញ្ចេញសំឡេង" else "Media audio output", fontWeight = FontWeight.Bold)
                Text(if (khmer) "ការកំណត់នេះប៉ះពាល់តែសំឡេងមេឌៀដែល CBTA ចាក់ប៉ុណ្ណោះ។ វាមិនអាចបញ្ជាឱ្យ TalkBack ប្ដូរទៅ Speaker ទូរសព្ទលើ Android គ្រប់ម៉ាកបានទេ។" else "This setting applies only to media played by CBTA. It cannot force TalkBack to use the phone speaker on every Android device.")
                outputOption(if (khmer) "ស្វ័យប្រវត្តិ (លំនាំដើម)" else "Automatic (system default)", selectedOutputKey == "AUTO") {
                    selectedOutputKey = "AUTO"; prefs.edit().putString("output_key", "AUTO").apply()
                }
                outputs.forEach { output ->
                    outputOption(output.name, selectedOutputKey == outputKey(output)) {
                        selectedOutputKey = outputKey(output); prefs.edit().putString("output_key", selectedOutputKey).apply()
                    }
                }
                if (outputs.size == 1) Text(if (khmer) "មិនទាន់រកឃើញឧបករណ៍បញ្ចេញសំឡេងផ្សេងទៀតទេ។ សូមភ្ជាប់ Bluetooth រួចចូលមកម្តងទៀត។" else "No additional output devices detected. Connect Bluetooth and return here.")
                Text(outputMessage, Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.primary)
                OutlinedButton(onClick = {
                    runCatching { context.startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }
                        .onFailure { runCatching { context.startActivity(Intent(Settings.ACTION_SETTINGS)) } }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (khmer) "បើកការកំណត់សំឡេង Android" else "Open Android sound settings") }
                OutlinedButton(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth()) { Text(if (khmer) "ស្វែងរកឧបករណ៍ម្ដងទៀត" else "Refresh audio devices") }
                Text(if (khmer) "ការជ្រើសរើសនេះជាការស្នើផ្លូវសំឡេង។ Android ឬក្រុមហ៊ុនផលិតទូរសព្ទអាចមិនអនុវត្តតាមគ្រប់ករណី។ យើងត្រូវសាកល្បងជាក់ស្តែងជាមួយ TalkBack និង Bluetooth។" else "This is a preferred route request. Android or the device manufacturer may not honor it in every case. Real-device testing with TalkBack and Bluetooth is required.")
                Divider(Modifier.padding(vertical = 8.dp))
                Text(if (khmer) "ឯកជនភាព" else "Privacy", fontWeight = FontWeight.Bold)
                Text(if (khmer) "កម្មវិធីមិនតម្រូវឱ្យបង្កើតគណនី និងមិនផ្ញើប្រវត្តិឯកសាររបស់អ្នកទៅម៉ាស៊ីនមេ CBTA ទេ។ តំណភ្ជាប់ត្រូវបានផ្ញើទៅប្រភពដែលអ្នកបានជ្រើស ដើម្បីទាញយក។" else "No account is required. CBTA does not send your media history to a CBTA server. Links are sent to the source you choose to download from.")
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("CBTA Media Center • Phase 1", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun navButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = modifier.semantics { role = Role.Tab; contentDescription = label }) {
        Text(if (selected) "• $label" else label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun outputOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(role = Role.RadioButton, onClick = onClick).padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, Modifier.padding(start = 8.dp))
    }
}

private fun availableOutputs(audioManager: AudioManager): List<OutputChoice> {
    val accepted = setOf(AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_BLE_SPEAKER, AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_HDMI)
    return audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in accepted }.map {
        OutputChoice(it.id, it.type, "${friendlyType(it.type)}: ${it.productName}", it)
    }.distinctBy { outputKey(it) }
}

private fun friendlyType(type: Int): String = when (type) {
    AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Phone speaker"
    AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired headset"
    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth"
    AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLE_SPEAKER -> "Bluetooth LE"
    AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB audio"
    AudioDeviceInfo.TYPE_HDMI -> "HDMI"
    else -> "Audio device"
}

private fun outputKey(choice: OutputChoice): String = "${choice.type}:${choice.name.substringAfter(": ")}" 

private fun inspectAndQueue(context: Context, rawUrl: String, khmer: Boolean): String {
    var finalUrl = rawUrl
    var mime = "application/octet-stream"
    var fileName = ""
    var connection: HttpURLConnection? = null
    try {
        connection = (URL(rawUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "HEAD"
            connectTimeout = 8000
            readTimeout = 8000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "CBTA-Media-Center/1.3 Android")
        }
        val code = connection.responseCode
        finalUrl = connection.url.toString()
        mime = connection.contentType?.substringBefore(';')?.trim()?.lowercase(Locale.ROOT) ?: mime
        fileName = filenameFromDisposition(connection.getHeaderField("Content-Disposition").orEmpty())
        if (code in 200..299 && (mime == "text/html" || mime == "application/xhtml+xml")) {
            return if (khmer) "ប្រភពនេះជាទំព័រវេប មិនមែនជាតំណឯកសារមេឌៀផ្ទាល់ទេ។ សូមប្រើតំណឯកសារផ្ទាល់។" else "This is a web page, not a direct media file. Use a direct media URL."
        }
        if (code in 400..499 && code != 405 && code != 403) {
            return if (khmer) "ម៉ាស៊ីនមេឆ្លើយតបកំហុស HTTP $code។ សូមពិនិត្យតំណ ឬសិទ្ធិចូលប្រើ។" else "Server returned HTTP $code. Check the URL or access permission."
        }
    } catch (_: Exception) {
        // Some legitimate servers do not support HEAD. DownloadManager will make the actual GET request.
    } finally { connection?.disconnect() }

    if (fileName.isBlank()) fileName = URLUtil.guessFileName(finalUrl, null, mime)
    fileName = sanitizeFilename(fileName)
    if (fileName.isBlank()) fileName = "CBTA_media_${System.currentTimeMillis()}"
    if (mime.startsWith("text/")) return if (khmer) "ប្រភេទឯកសារនេះមិនមែនជាសំឡេង ឬវីដេអូទេ។" else "The server did not identify this as audio or video."

    return try {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val request = DownloadManager.Request(Uri.parse(finalUrl))
            .setTitle(fileName)
            .setDescription("CBTA Media Center")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        if (mime != "application/octet-stream") request.setMimeType(mime)
        val id = manager.enqueue(request)
        val prefs = context.getSharedPreferences("cbta_media_center", Context.MODE_PRIVATE)
        val ids = prefs.getStringSet("download_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.add(id.toString())
        prefs.edit().putStringSet("download_ids", ids).apply()
        if (khmer) "បានបញ្ចូលការទាញយក៖ $fileName" else "Download queued: $fileName"
    } catch (e: Exception) {
        if (khmer) "មិនអាចចាប់ផ្ដើមទាញយកបានទេ៖ ${e.localizedMessage ?: "កំហុសមិនស្គាល់"}" else "Could not start download: ${e.localizedMessage ?: "Unknown error"}"
    }
}

private fun loadDownloads(context: Context, target: MutableList<DownloadEntry>) {
    val prefs = context.getSharedPreferences("cbta_media_center", Context.MODE_PRIVATE)
    val ids = prefs.getStringSet("download_ids", emptySet())?.mapNotNull { it.toLongOrNull() }.orEmpty()
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val found = ids.mapNotNull { id ->
        try {
            val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return@mapNotNull null
            cursor.use {
                if (!it.moveToFirst()) return@mapNotNull null
                val title = it.getString(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)).orEmpty()
                val statusCode = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val downloaded = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val reason = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                val progress = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else -1
                val state = when (statusCode) {
                    DownloadManager.STATUS_SUCCESSFUL -> "COMPLETE"
                    DownloadManager.STATUS_FAILED -> "FAILED"
                    DownloadManager.STATUS_PAUSED -> "PAUSED"
                    DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PENDING -> "RUNNING"
                    else -> "UNKNOWN"
                }
                DownloadEntry(id, title, state, if (state == "FAILED") "Code $reason" else if (total > 0) "${formatBytes(downloaded)} / ${formatBytes(total)}" else "", progress)
            }
        } catch (_: Exception) { null }
    }.sortedByDescending { it.id }
    target.clear(); target.addAll(found)
}

private fun DownloadEntry.statusText(khmer: Boolean): String = when (status) {
    "COMPLETE" -> if (khmer) "បានបញ្ចប់" else "Completed"
    "FAILED" -> if (khmer) "បរាជ័យ" else "Failed"
    "PAUSED" -> if (khmer) "បានផ្អាកដោយប្រព័ន្ធ" else "Paused by system"
    "RUNNING" -> if (khmer) "កំពុងទាញយក" else "Downloading"
    else -> if (khmer) "មិនស្គាល់ស្ថានភាព" else "Unknown status"
}

private fun formatBytes(value: Long): String = when {
    value >= 1024L * 1024L * 1024L -> String.format(Locale.ROOT, "%.1f GB", value / (1024.0 * 1024.0 * 1024.0))
    value >= 1024L * 1024L -> String.format(Locale.ROOT, "%.1f MB", value / (1024.0 * 1024.0))
    value >= 1024L -> String.format(Locale.ROOT, "%.1f KB", value / 1024.0)
    else -> "$value B"
}

private fun filenameFromDisposition(header: String): String {
    if (header.isBlank()) return ""
    val star = Pattern.compile("filename\\*=UTF-8''([^;]+)", Pattern.CASE_INSENSITIVE).matcher(header)
    if (star.find()) return runCatching { URLDecoder.decode(star.group(1), StandardCharsets.UTF_8.name()) }.getOrDefault("")
    val normal = Pattern.compile("filename=\\\"?([^\\\";]+)", Pattern.CASE_INSENSITIVE).matcher(header)
    return if (normal.find()) normal.group(1).trim() else ""
}

private fun sanitizeFilename(name: String): String = name.substringAfterLast('/').substringAfterLast('\\')
    .replace(Regex("[\\u0000-\\u001F<>:\"/\\\\|?*]"), "_").trim().take(180)

private fun isYoutubeHost(host: String): Boolean {
    val value = host.lowercase(Locale.ROOT)
    return value == "youtu.be" || value == "youtube.com" || value.endsWith(".youtube.com") ||
        value == "youtube-nocookie.com" || value.endsWith(".youtube-nocookie.com")
}
