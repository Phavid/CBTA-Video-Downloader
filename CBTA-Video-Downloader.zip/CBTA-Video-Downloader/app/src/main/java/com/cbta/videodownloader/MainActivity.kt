
package com.cbta.videodownloader

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private val sharedText = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedText.value = getSharedText(intent)

        setContent {
            MaterialTheme {
                VideoDownloaderApp(
                    sharedUrl = sharedText.value
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedText.value = getSharedText(intent)
    }

    private fun getSharedText(intent: Intent?): String {
        if (
            intent?.action == Intent.ACTION_SEND &&
            intent.type == "text/plain"
        ) {
            return intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        }

        return ""
    }
}

@Composable
fun VideoDownloaderApp(sharedUrl: String) {

    var isKhmer by remember { mutableStateOf(true) }
    var videoUrl by remember { mutableStateOf(sharedUrl) }
    var selectedFormat by remember { mutableStateOf("MP4") }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(sharedUrl) {
        if (sharedUrl.isNotBlank()) {
            videoUrl = sharedUrl
            message = ""
        }
    }

    val title = "CBTA Video Downloader"

    val languageText = if (isKhmer) "English" else "ភាសាខ្មែរ"

    val urlLabel = if (isKhmer)
        "បញ្ចូលតំណភ្ជាប់វីដេអូ"
    else "Enter video URL"

    val formatLabel = if (isKhmer)
        "ជ្រើសរើសទម្រង់ឯកសារ"
    else "Select file format"

    val buttonText = if (isKhmer)
        "ពិនិត្យតំណភ្ជាប់"
    else "Check link"

    val description = if (isKhmer)
        "កម្មវិធីទាញយកវីដេអូសម្រាប់ CBTA"
    else "CBTA video downloader application"

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge
                )

                TextButton(
                    onClick = {
                        isKhmer = !isKhmer
                        message = ""
                    }
                ) {
                    Text(languageText)
                }
            }

            Text(
                text = description,
                style = MaterialTheme.typography.bodyLarge
            )

            HorizontalDivider()

            OutlinedTextField(
                value = videoUrl,
                onValueChange = {
                    videoUrl = it
                    message = ""
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(urlLabel) },
                singleLine = false,
                minLines = 2
            )

            Text(
                text = formatLabel,
                style = MaterialTheme.typography.titleMedium
            )

            listOf("MP4", "MP3", "WAV").forEach { format ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(
                            selected = selectedFormat == format,
                            onClick = { selectedFormat = format },
                            role = Role.RadioButton
                        )
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedFormat == format,
                        onClick = { selectedFormat = format }
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = format,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            Button(
                onClick = {
                    message = if (videoUrl.isBlank()) {
                        if (isKhmer)
                            "សូមបញ្ចូលតំណភ្ជាប់ជាមុនសិន។"
                        else
                            "Please enter a video URL first."
                    } else {
                        if (isKhmer)
                            "តំណភ្ជាប់ត្រូវបានបញ្ចូលរួចហើយ។ ប្រព័ន្ធទាញយកនឹងត្រូវបន្ថែមនៅជំហានបន្ទាប់។"
                        else
                            "Link received. The download engine will be added in the next development step."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(buttonText)
            }

            if (message.isNotEmpty()) {
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            HorizontalDivider()

            Text(
                text = if (isKhmer)
                    "បង្កើតដោយ Cambodian Blind Tech Access (CBTA)"
                else
                    "Developed by Cambodian Blind Tech Access (CBTA)",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

