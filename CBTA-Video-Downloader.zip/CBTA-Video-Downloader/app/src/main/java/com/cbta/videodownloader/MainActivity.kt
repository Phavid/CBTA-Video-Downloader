package com.cbta.videodownloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.URLDecoder
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var sharedLink by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedLink = readSharedText(intent)
        showApp()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedLink = readSharedText(intent)
    }

    private fun readSharedText(source: Intent?): String {
        if (source?.action == Intent.ACTION_SEND && source.type?.startsWith("text/") == true) {
            return source.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        }
        return ""
    }

    private fun showApp() {
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    DownloaderScreen(sharedLink = sharedLink)
                }
            }
        }
    }
}

private enum class DownloadFormat(val extension: String, val mimeType: String) {
    MP4("mp4", "video/mp4"),
    MP3("mp3", "audio/mpeg"),
    WAV("wav", "audio/wav")
}

@Composable
private fun DownloaderScreen(sharedLink: String) {
    val context = LocalContext.current
    var url by remember { mutableStateOf(sharedLink) }
    var selectedFormat by remember { mutableStateOf(DownloadFormat.MP4) }
    var isKhmer by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("") }
    var previewUrl by remember { mutableStateOf("") }
    var previewError by remember { mutableStateOf("") }
    val exoPlayer = remember(context) { ExoPlayer.Builder(context).build() }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                previewError = if (isKhmer) {
                    "មិនអាចចាក់ប្រភពនេះបានទេ។ សូមពិនិត្យតំណភ្ជាប់ ឬសាកល្បងប្រភពផ្សេង។"
                } else {
                    "This source could not be played. Check the link or try another source."
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(sharedLink) {
        if (sharedLink.isNotBlank()) url = sharedLink.trim()
    }

    val title = if (isKhmer) "CBTA កម្មវិធីទាញយកវីដេអូ" else "CBTA Video Downloader"
    val instruction = if (isKhmer)
        "បញ្ចូលតំណភ្ជាប់ឯកសារមេឌៀ ឬចែករំលែកតំណភ្ជាប់មកកាន់កម្មវិធីនេះ។"
    else "Paste a media link or share a link to this app."
    val linkLabel = if (isKhmer) "តំណភ្ជាប់" else "Media URL"
    val formatLabel = if (isKhmer) "ជ្រើសរើសទម្រង់ឯកសារទាញយក" else "Choose download format"
    val previewLabel = if (isKhmer) "មើល ឬស្តាប់ជាមុន" else "Preview video or audio"
    val downloadLabel = if (isKhmer) "ចាប់ផ្តើមទាញយក" else "Start download"
    val clearLabel = if (isKhmer) "សម្អាត" else "Clear"
    val stopLabel = if (isKhmer) "បញ្ឈប់ការចាក់" else "Stop preview"
    val note = if (isKhmer)
        "ចំណាំ៖ ការមើលជាមុន និងការទាញយកអាស្រ័យលើប្រភព និងសិទ្ធិប្រើប្រាស់។ តំណ YouTube នឹងបើកក្នុងកម្មវិធី ឬកម្មវិធីរុករក YouTube ផ្លូវការ។ កម្មវិធីនេះមិនរំលងការការពារឬការកំណត់របស់គេហទំព័រទេ។"
    else
        "Note: Preview and downloads depend on the source and your rights to use it. YouTube links open in the official YouTube app or browser. This app does not bypass site protections or restrictions."

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { isKhmer = !isKhmer }) {
                Text(if (isKhmer) "English" else "ភាសាខ្មែរ")
            }
        }

        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(instruction)
        Spacer(Modifier.height(18.dp))

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(linkLabel) },
            placeholder = { Text("https://example.com/media.mp4") },
            minLines = 3,
            maxLines = 5
        )

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                previewError = ""
                val clean = url.trim()
                val parsed = runCatching { Uri.parse(clean) }.getOrNull()
                if (clean.isBlank() || parsed?.scheme !in listOf("http", "https") || parsed.host.isNullOrBlank()) {
                    status = if (isKhmer) "សូមបញ្ចូលតំណភ្ជាប់ http ឬ https ត្រឹមត្រូវ។" else "Enter a valid http or https link."
                } else if (isYoutubeHost(parsed.host.orEmpty())) {
                    previewUrl = ""
                    exoPlayer.stop()
                    val intent = Intent(Intent.ACTION_VIEW, parsed).addCategory(Intent.CATEGORY_BROWSABLE)
                    try {
                        context.startActivity(intent)
                        status = if (isKhmer) "កំពុងបើក YouTube ដើម្បីមើលជាមុន។" else "Opening YouTube for preview."
                    } catch (_: Exception) {
                        status = if (isKhmer) "មិនអាចបើក YouTube បានទេ។" else "Could not open YouTube."
                    }
                } else {
                    previewUrl = clean
                    try {
                        exoPlayer.setMediaItem(MediaItem.fromUri(clean))
                        exoPlayer.prepare()
                        exoPlayer.playWhenReady = true
                        status = if (isKhmer) "កំពុងព្យាយាមចាក់មើលជាមុន។" else "Trying to play preview."
                    } catch (error: Exception) {
                        previewError = error.message.orEmpty()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(previewLabel) }

        if (previewUrl.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(if (isKhmer) "កម្មវិធីចាក់មើលជាមុន" else "Preview player", fontWeight = FontWeight.Bold)
            AndroidView(
                factory = { viewContext ->
                    PlayerView(viewContext).apply {
                        player = exoPlayer
                        useController = true
                        controllerAutoShow = true
                        contentDescription = if (isKhmer) "កម្មវិធីចាក់វីដេអូ និងសំឡេង" else "Video and audio player"
                    }
                },
                update = { it.player = exoPlayer },
                modifier = Modifier.fillMaxWidth().height(230.dp)
            )
            TextButton(onClick = {
                exoPlayer.stop()
                previewUrl = ""
                previewError = ""
            }) { Text(stopLabel) }
        }

        if (previewError.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(previewError, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(18.dp))
        Text(formatLabel, fontWeight = FontWeight.Bold)
        DownloadFormat.values().forEach { format ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                RadioButton(selected = selectedFormat == format, onClick = { selectedFormat = format })
                Text(format.name, modifier = Modifier.padding(start = 8.dp))
            }
        }

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                status = startDownload(context, url, selectedFormat, isKhmer)
                Toast.makeText(context, status, Toast.LENGTH_LONG).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(downloadLabel) }

        TextButton(onClick = {
            exoPlayer.stop()
            previewUrl = ""
            previewError = ""
            url = ""
            status = ""
        }, modifier = Modifier.align(Alignment.End)) { Text(clearLabel) }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text((if (isKhmer) "ស្ថានភាព៖ " else "Status: ") + status)
        }
        Spacer(Modifier.height(20.dp))
        Text(note, style = MaterialTheme.typography.bodyMedium)
    }
}

private fun isYoutubeHost(host: String): Boolean {
    val normalized = host.lowercase(Locale.ROOT)
    return normalized == "youtu.be" || normalized == "youtube.com" || normalized.endsWith(".youtube.com") || normalized == "youtube-nocookie.com" || normalized.endsWith(".youtube-nocookie.com")
}

private fun startDownload(context: Context, rawUrl: String, format: DownloadFormat, isKhmer: Boolean): String {
    fun message(kh: String, en: String) = if (isKhmer) kh else en
    val cleanUrl = rawUrl.trim()
    if (cleanUrl.isEmpty()) return message("សូមបញ្ចូលតំណភ្ជាប់ជាមុនសិន។", "Please enter a URL first.")

    val uri = try { Uri.parse(cleanUrl) } catch (_: Exception) {
        return message("តំណភ្ជាប់មិនត្រឹមត្រូវទេ។", "The URL is invalid.")
    }

    if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
        return message("សូមប្រើតំណភ្ជាប់ដែលចាប់ផ្តើមដោយ http:// ឬ https://។", "Use a valid http:// or https:// URL.")
    }

    if (isYoutubeHost(uri.host.orEmpty())) {
        return message(
            "តំណ YouTube មិនអាចទាញយកដោយផ្ទាល់តាមកម្មវិធីនេះបានទេ។ អ្នកអាចមើលវាតាម YouTube ផ្លូវការ។",
            "YouTube links cannot be downloaded directly by this app. You can view them using official YouTube."
        )
    }

    val path = uri.lastPathSegment.orEmpty().lowercase(Locale.ROOT)
    if (!path.endsWith(".${format.extension}")) {
        return message(
            "តំណនេះមិនបញ្ជាក់ថាជាឯកសារ .${format.extension} ទេ។ សូមប្រើតំណឯកសារផ្ទាល់ដែលត្រូវនឹងទម្រង់នេះ។",
            "This link does not identify a direct .${format.extension} file. Use a direct file link matching this format."
        )
    }

    return try {
        val decodedName = URLDecoder.decode(uri.lastPathSegment ?: "", "UTF-8")
        val safeName = decodedName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "cbta_download.${format.extension}" }
        val request = DownloadManager.Request(uri)
            .setTitle(safeName)
            .setDescription("CBTA Video Downloader")
            .setMimeType(format.mimeType)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeName)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        message("បានដាក់សំណើទាញយកហើយ។ សូមពិនិត្យការជូនដំណឹង និងថត Downloads។", "Download queued. Check notifications and the Downloads folder.")
    } catch (error: Exception) {
        message("មិនអាចចាប់ផ្តើមទាញយកបានទេ៖ ${error.message ?: "កំហុសមិនស្គាល់"}", "Could not start download: ${error.message ?: "Unknown error"}")
    }
}
