package com.cbta.videodownloader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedText = if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        } else {
            ""
        }

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DownloaderHome(initialLink = sharedText)
                }
            }
        }
    }
}

@Composable
private fun DownloaderHome(initialLink: String) {

    var isKhmer by rememberSaveable {
        mutableStateOf(true)
    }

    var videoLink by rememberSaveable {
        mutableStateOf(initialLink)
    }

    var selectedFormat by rememberSaveable {
        mutableStateOf("MP4")
    }

    var message by rememberSaveable {
        mutableStateOf("")
    }

    val title = if (isKhmer) {
        "CBTA ទាញយកវីដេអូ"
    } else {
        "CBTA Video Downloader"
    }

    val description = if (isKhmer) {
        "កម្មវិធីជំនួយសម្រាប់រៀបចំតំណភ្ជាប់វីដេអូ និងសំឡេង។"
    } else {
        "A simple helper for preparing video and audio links."
    }

    val linkLabel = if (isKhmer) {
        "បញ្ចូល ឬបិទភ្ជាប់តំណភ្ជាប់"
    } else {
        "Enter or paste a link"
    }

    val formatLabel = if (isKhmer) {
        "ជ្រើសរើសទម្រង់ឯកសារ"
    } else {
        "Choose file format"
    }

    val checkLabel = if (isKhmer) {
        "ពិនិត្យតំណភ្ជាប់"
    } else {
        "Check link"
    }

    val shareLabel = if (isKhmer) {
        "ចែករំលែកតំណមកកម្មវិធីនេះ"
    } else {
        "Share a link to this app"
    }

    val languageLabel = if (isKhmer) {
        "English"
    } else {
        "ភាសាខ្មែរ"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(
                onClick = {
                    isKhmer = !isKhmer
                }
            ) {
                Text(languageLabel)
            }
        }

        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = description,
            style = MaterialTheme.typography.bodyLarge
        )

        Spacer(modifier = Modifier.height(4.dp))

        OutlinedTextField(
            value = videoLink,
            onValueChange = {
                videoLink = it
                message = ""
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text(linkLabel)
            },
            supportingText = {
                Text(
                    if (isKhmer) {
                        "អ្នកអាចបិទភ្ជាប់តំណ ឬប្រើមុខងារ Share ពីកម្មវិធីផ្សេង។"
                    } else {
                        "Paste a link or use Share from another app."
                    }
                )
            },
            singleLine = false,
            minLines = 2
        )

        Text(
            text = formatLabel,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )

        listOf("MP4", "MP3", "WAV").forEach { format ->

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                RadioButton(
                    selected = selectedFormat == format,
                    onClick = {
                        selectedFormat = format
                    }
                )

                TextButton(
                    onClick = {
                        selectedFormat = format
                    }
                ) {
                    Text(format)
                }
            }
        }

        Button(
            onClick = {

                val trimmedLink = videoLink.trim()
                val parsed = Uri.parse(trimmedLink)

                val validScheme =
                    parsed.scheme == "http" ||
                    parsed.scheme == "https"

                val hasHost = !parsed.host.isNullOrBlank()

                message = if (trimmedLink.isBlank()) {

                    if (isKhmer) {
                        "សូមបញ្ចូលតំណភ្ជាប់ជាមុនសិន។"
                    } else {
                        "Please enter a link first."
                    }

                } else if (validScheme && hasHost) {

                    if (isKhmer) {
                        "តំណភ្ជាប់មានទម្រង់ត្រឹមត្រូវ។ ទម្រង់ដែលបានជ្រើស៖ $selectedFormat។ មុខងារទាញយកមិនទាន់បានបង្កើតទេ។"
                    } else {
                        "The link format looks valid. Selected format: $selectedFormat. Downloading is not implemented yet."
                    }

                } else {

                    if (isKhmer) {
                        "តំណភ្ជាប់មិនត្រឹមត្រូវទេ។ សូមពិនិត្យម្ដងទៀត។"
                    } else {
                        "This link does not look valid. Please check it."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(checkLabel)
        }

        TextButton(
            onClick = {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, videoLink)
                }

                val chooser = Intent.createChooser(
                    sendIntent,
                    shareLabel
                )

                startActivity(chooser)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(shareLabel)
        }

        if (message.isNotBlank()) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
