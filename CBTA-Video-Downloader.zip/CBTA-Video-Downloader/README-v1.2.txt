CBTA Video Downloader - Source v1.2

Changes in this version:
- Adds in-app preview playback for supported direct audio/video streams using AndroidX Media3 ExoPlayer.
- Supports HLS and DASH playback modules in addition to progressive media files.
- YouTube links open in the official YouTube app or browser for viewing; the app does not download YouTube audiovisual content.
- Keeps direct-file downloads for matching MP4, MP3, and WAV URLs.
- Keeps the existing applicationId so this remains the same Android app identity.

Build:
- Android Gradle project
- Java 17
- Android SDK 35
- Gradle 8.9
- Media3 1.8.0

Important:
Preview support depends on the server providing a compatible, accessible stream. Some sites require sign-in, cookies, special request headers, DRM, or other access controls; those sources may not play in the preview player. Downloading remains limited to direct file links that the user is authorized to save.
